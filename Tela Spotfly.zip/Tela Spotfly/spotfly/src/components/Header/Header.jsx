import styles from './styles.module.css';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline'; // Para ícone de contorno
import { Bars3Icon } from '@heroicons/react/24/outline';

export default function Header() {
    return (
        <div className={styles.header}>
            <a className={styles.header__logo} href='#'></a>

            <form className={styles.header__search}>
                <label className={styles.header__search_label} htmlFor='search'>
                    <MagnifyingGlassIcon className={styles.header__search_icon} />
                    <input
                        type='search'
                        id='search' // Adicionado o id para associar com o label
                        placeholder='O que você deseja ouvir'
                        className={styles.header__search_input} // Corrigido para usar a classe correta
                    />
                </label>
            </form>

            <div className={styles.header__actions}>
                <button className={styles.header__button}>
                    <MagnifyingGlassIcon className={styles.header__button_icon} />
                </button>
                <a className={styles.header__links} href='#'>Abrir App</a>
                <button className={styles.header__button}>
                    <Bars3Icon className={styles.header__button_icon} />
                </button>
            </div>

            <div className={styles.header__signup}>
                <a className={styles.cadastrar} href=''>Cadastrar </a>
                <a href={styles.login}>Login</a>
            </div>
 

        </div>
    );
}
